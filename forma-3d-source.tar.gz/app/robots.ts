import type {MetadataRoute} from 'next';
import {SITE_URL} from './seo';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{userAgent: '*', allow: '/', disallow: ['/api/', '/ru/cart', '/uz/cart', '/ru/account', '/uz/account']}],
    sitemap: `${SITE_URL}/sitemap.xml`,
    host: SITE_URL,
  };
}
