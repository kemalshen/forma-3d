import Store from '../../store';
export default async function Page({params}: {params: Promise<{lang:string;path?:string[]}>}) {
  const {lang,path=[]}=await params;
  return <Store initialPath={`/${lang}/${path.join('/')}`} />;
}
