// Store contacts are set in Railway → Variables (no rebuild needed to change them):
//   CONTACT_PHONE    — phone as it should be displayed, e.g. "+998 90 123 45 67"
//   CONTACT_TELEGRAM — Telegram username without @, e.g. "forma3d_uz"
// Leave a variable empty to hide that contact on the site.
export type Contacts = {phone: string; telegram: string};

export function readContacts(): Contacts {
  return {
    phone: (process.env.CONTACT_PHONE || '').trim(),
    telegram: (process.env.CONTACT_TELEGRAM || '').trim().replace(/^@/, '').replace(/^https?:\/\/t\.me\//, ''),
  };
}

export const telHref = (phone: string) => `tel:${phone.replace(/[^\d+]/g, '')}`;
export const tgHref = (user: string, text = '') =>
  user ? `https://t.me/${user}${text ? `?text=${encodeURIComponent(text)}` : ''}` : '';
