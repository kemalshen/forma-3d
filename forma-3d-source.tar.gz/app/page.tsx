import Store from './store';
export default function Home() { return <Store initialPath="/ru/" />; }
