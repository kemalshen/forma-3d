import type {Metadata} from 'next';
import {products, productBrand, type Product} from './catalog';

// Public address of the site. Can be overridden with the SITE_URL env var.
export const SITE_URL = (process.env.SITE_URL || 'https://forma-3d.uz').replace(/\/$/, '');
export const LANGS = ['ru', 'uz'] as const;
export type Lang = (typeof LANGS)[number];

// Pages the store can render. Anything else returns a real 404.
export const PAGES = ['', 'catalog', 'product', 'cart', 'business', 'account', 'delivery', 'contacts', 'knowledge', 'offer', 'privacy', 'returns'] as const;
// Indexable pages that go into the sitemap (cart / account are private).
export const SITEMAP_PAGES = ['', 'catalog', 'catalog/parts', 'business', 'delivery', 'contacts', 'knowledge', 'offer', 'privacy', 'returns'];

export function findProduct(id?: string) {
  return id ? products.find((p) => p.id === id) : undefined;
}

/** Returns true when the path (without language) is a page the store can show. */
export function isValidPath(path: string[]) {
  const [page = '', sub, extra] = path;
  if (!(PAGES as readonly string[]).includes(page)) return false;
  if (page === 'product') return path.length === 2 && !!findProduct(sub);
  if (page === 'catalog') return !sub || (sub === 'parts' && !extra);
  return path.length <= 1;
}

const priceText = (p: Product, uz: boolean) =>
  p.price == null ? '' : `${new Intl.NumberFormat('ru-RU').format(p.price).replace(/ /g, ' ')} ${uz ? 'so‘m' : 'сум'}`;

export function productTitle(p: Product, uz: boolean) {
  const name = uz ? p.uzName || p.name : p.name;
  if (p.type === 'filament') return `${productBrand(p)} ${name}, ${uz ? p.uzColor : p.color}`.trim();
  return `${name} · Bambu Lab ${p.color}`;
}

function productDescription(p: Product, uz: boolean) {
  const price = priceText(p, uz);
  if (p.type === 'filament')
    return uz
      ? `${productTitle(p, uz)}, 1 kg. ${price ? 'Narxi ' + price + '. ' : ''}Toshkent bo‘ylab kuryer va O‘zbekiston bo‘ylab yetkazib berish. Forma 3D — 3D-bosma uchun hamma narsa.`
      : `Купить ${productTitle(p, uz)}, 1 кг${price ? ' — ' + price : ''}. Доставка курьером по Ташкенту и в регионы Узбекистана. Forma 3D — всё для 3D-печати.`;
  return uz
    ? `${productTitle(p, uz)}. ${price ? 'Narxi ' + price + '. ' : 'Narxi so‘rov bo‘yicha. '}Bambu Lab printerlari uchun ehtiyot qismlar Toshkentda.`
    : `${productTitle(p, uz)}. ${price ? 'Цена ' + price + '. ' : 'Цена по запросу. '}Запчасти и расходники для принтеров Bambu Lab в Ташкенте.`;
}

const PAGE_META: Record<string, {ru: [string, string]; uz: [string, string]}> = {
  '': {
    ru: ['Forma 3D — филамент и запчасти Bambu Lab в Ташкенте', 'Филамент Bambu Lab, расходники и запчасти для 3D-принтеров в Ташкенте с доставкой по Узбекистану. Оптовые условия для бизнеса и учебных заведений.'],
    uz: ['Forma 3D — Toshkentda Bambu Lab filamenti va ehtiyot qismlari', 'Bambu Lab filamenti, 3D-printerlar uchun sarf materiallari va ehtiyot qismlar Toshkentda, O‘zbekiston bo‘ylab yetkazib berish bilan.'],
  },
  catalog: {
    ru: ['Каталог филамента Bambu Lab — PLA, PETG, ABS и др.', 'Филамент Bambu Lab: PLA, PETG, ABS, TPU и другие материалы. Выбор по цвету, материалу и модели принтера. Доставка по Ташкенту и Узбекистану.'],
    uz: ['Bambu Lab filamenti katalogi — PLA, PETG, ABS va boshqalar', 'Bambu Lab filamenti: PLA, PETG, ABS, TPU va boshqa materiallar. Rang, material va printer modeli bo‘yicha tanlash.'],
  },
  'catalog/parts': {
    ru: ['Запчасти и расходники для принтеров Bambu Lab', 'Хотэнды и сопла, печатные пластины, компоненты AMS, наборы обслуживания и расходники для принтеров Bambu Lab A1, P1S, X1C, H2D и других. Подбор по модели принтера.'],
    uz: ['Bambu Lab printerlari uchun ehtiyot qismlar', 'Bambu Lab A1, P1S, X1C, H2D va boshqa printerlar uchun hotendlar va soplolar, bosma plastinalar, AMS qismlari, xizmat ko‘rsatish to‘plamlari va sarf materiallari.'],
  },
  business: {
    ru: ['Филамент оптом для бизнеса и учебных заведений', 'Оптовые поставки филамента и запчастей Bambu Lab для принт-ферм, мастерских, школ и вузов. Счёт, договор, закрывающие документы.'],
    uz: ['Biznes va ta’lim muassasalari uchun ulgurji filament', 'Print-fermalar, ustaxonalar, maktab va oliygohlar uchun Bambu Lab filamenti va ehtiyot qismlarini ulgurji yetkazib berish.'],
  },
  delivery: {ru: ['Доставка и оплата', 'Курьерская доставка по Ташкенту, самовывоз и доставка в регионы Узбекистана. Способы оплаты.'], uz: ['Yetkazish va to‘lov', 'Toshkent bo‘ylab kuryer, olib ketish va viloyatlarga yetkazish. To‘lov usullari.']},
  contacts: {ru: ['Контакты', 'Как связаться с Forma 3D: телефон, Telegram, адрес.'], uz: ['Kontaktlar', 'Forma 3D bilan bog‘lanish: telefon, Telegram, manzil.']},
  knowledge: {ru: ['База знаний по 3D-печати', 'Как выбрать филамент, чем отличаются PLA и PETG, как хранить материалы и обслуживать принтер.'], uz: ['3D-bosma bo‘yicha bilimlar bazasi', 'Filamentni qanday tanlash, PLA va PETG farqi, materiallarni saqlash va printerga xizmat ko‘rsatish.']},
  offer: {ru: ['Публичная оферта', 'Публичная оферта интернет-магазина Forma 3D.'], uz: ['Ommaviy oferta', 'Forma 3D internet-do‘konining ommaviy ofertasi.']},
  privacy: {ru: ['Политика конфиденциальности', 'Политика обработки персональных данных Forma 3D.'], uz: ['Maxfiylik siyosati', 'Forma 3D shaxsiy ma’lumotlarni qayta ishlash siyosati.']},
  returns: {ru: ['Возврат и обмен', 'Условия возврата и обмена товаров Forma 3D.'], uz: ['Qaytarish va almashtirish', 'Forma 3D mahsulotlarini qaytarish va almashtirish shartlari.']},
  cart: {ru: ['Корзина', 'Корзина Forma 3D.'], uz: ['Savat', 'Forma 3D savati.']},
  account: {ru: ['Личный кабинет', 'Личный кабинет Forma 3D.'], uz: ['Shaxsiy kabinet', 'Forma 3D shaxsiy kabineti.']},
};

export function buildMetadata(lang: Lang, path: string[], catalogPage = 1): Metadata {
  const uz = lang === 'uz';
  const rest = path.join('/');
  const pageQuery = path[0] === 'catalog' && catalogPage > 1 ? `?page=${catalogPage}` : '';
  const url = (l: Lang) => `${SITE_URL}/${l}${rest ? '/' + rest : ''}${pageQuery}`;
  const alternates = {canonical: url(lang), languages: {ru: url('ru'), uz: url('uz'), 'x-default': url('ru')}};
  const product = path[0] === 'product' ? findProduct(path[1]) : undefined;

  let title: string;
  let description: string;
  let image: string | undefined;
  if (product) {
    title = `${productTitle(product, uz)} — ${uz ? 'sotib olish' : 'купить в Ташкенте'}`;
    description = productDescription(product, uz);
    image = product.image ? `${SITE_URL}/images/${product.image}` : undefined;
  } else {
    const key = path[0] === 'catalog' && path[1] === 'parts' ? 'catalog/parts' : path[0] || '';
    [title, description] = (PAGE_META[key] ?? PAGE_META[''])[lang];
  }
  if (pageQuery) title = `${title} — ${uz ? catalogPage + '-sahifa' : 'страница ' + catalogPage}`;
  const fullTitle = title.includes('Forma 3D') ? title : `${title} | Forma 3D`;
  const privatePage = path[0] === 'cart' || path[0] === 'account';

  return {
    title: {absolute: fullTitle},
    description,
    alternates,
    robots: privatePage ? {index: false, follow: true} : undefined,
    openGraph: {
      type: 'website',
      siteName: 'Forma 3D',
      locale: uz ? 'uz_UZ' : 'ru_RU',
      url: url(lang),
      title: fullTitle,
      description,
      ...(image ? {images: [{url: image}]} : {}),
    },
  };
}

/** schema.org Product markup for product pages (helps rich results). */
export function productJsonLd(p: Product, lang: Lang) {
  const uz = lang === 'uz';
  return {
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: productTitle(p, uz),
    sku: p.id,
    brand: {'@type': 'Brand', name: productBrand(p) || 'Bambu Lab'},
    ...(p.image ? {image: `${SITE_URL}/images/${p.image}`} : {}),
    description: productDescription(p, uz),
    ...(p.price != null
      ? {
          offers: {
            '@type': 'Offer',
            price: p.price,
            priceCurrency: 'UZS',
            availability: (p.stock ?? 0) > 0 ? 'https://schema.org/InStock' : 'https://schema.org/OutOfStock',
            url: `${SITE_URL}/${lang}/product/${p.id}`,
          },
        }
      : {}),
  };
}
