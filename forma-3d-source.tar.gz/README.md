# Forma 3D

**Всё для вашей 3D-печати.**

Готовая внешняя часть магазина на русском и узбекском: главная, каталог филамента и расходников, карточки товаров, фильтры, корзина, кабинет, разделы для бизнеса и клиентов. Все фотографии и логотипы находятся в `public/`.

Это версия для самостоятельного размещения на Railway или другом хостинге Node.js. Стек: Next.js 16, React 19, TypeScript и Tailwind CSS 4. Запуск не зависит от ChatGPT, Cloudflare, Sites или внешних API.

## 1. Загрузить на GitHub

1. Распакуйте архив. Откройте папку `forma-3d`, внутри которой находятся `package.json` и `Dockerfile`.
2. Создайте на GitHub пустой репозиторий, например `forma-3d`, без автоматически созданных README и `.gitignore`.
3. Откройте терминал в распакованной папке и выполните команды. В адресе замените `YOUR_USERNAME` на свой логин GitHub:

```bash
git init
git add .
git commit -m "Add Forma 3D website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/forma-3d.git
git push -u origin main
```

Файлы `Dockerfile`, `package.json` и `pnpm-lock.yaml` должны находиться в корне репозитория. Загружайте содержимое папки `forma-3d`, а не сам ZIP. Если используете веб-интерфейс GitHub, сохраните структуру папок и включите `.gitignore` и `.dockerignore`.

## 2. Разместить на Railway

1. В Railway создайте проект: **New Project → Deploy from GitHub repo**.
2. Выберите репозиторий `forma-3d` и ветку `main`.
3. Корневая директория сервиса — корень репозитория. Railway обнаруживает файл `Dockerfile` автоматически. Отдельные Build Command и Start Command задавать не нужно: они уже указаны в Dockerfile.
4. Дождитесь успешного развёртывания.
5. В сервисе откройте **Settings → Networking → Public Networking → Generate Domain**, затем откройте выданный адрес.
6. При желании укажите `/api/health` в настройке **Healthcheck Path**. Маршрут возвращает HTTP 200 и JSON со статусом `ok`.

Для этой версии не нужны база данных, тома, ключи API или дополнительные переменные окружения. Railway предоставляет `PORT`; сервер слушает этот порт на `0.0.0.0`. Если интерфейс просит целевой порт для домена, укажите порт сервиса, который виден в логах запуска. Стандартное локальное значение — `3000`.

Последующие изменения можно отправлять обычным `git push` в подключённую ветку.

## 3. Локальная разработка

Установите Node.js 22.13 или новее и pnpm 11.25.0:

```bash
npm install --global pnpm@11.25.0
pnpm install --frozen-lockfile
pnpm dev
```

Откройте `http://localhost:3000`. Русская версия: `/ru/`, узбекская: `/uz/`.

Проверка типов и production-сборка:

```bash
pnpm typecheck
pnpm build
pnpm start
```

`pnpm start` учитывает переменную `PORT`. Docker использует оптимизированный standalone-сервер из `.next/standalone`.

При установленном Docker можно проверить тот же образ, который собирает Railway:

```bash
docker build -t forma-3d .
docker run --rm -p 3000:3000 forma-3d
```

## 4. Что редактировать

| Файл или папка | Содержимое |
| --- | --- |
| `app/store.tsx` | Страницы, тексты, языки, фильтры и интерфейс магазина |
| `app/globals.css` | Цвета, шрифты, адаптивная вёрстка |
| `app/layout.tsx` | Заголовок вкладки, описание сайта, favicon |
| `app/catalog.ts` | Товары, модели принтеров, фильтрация и рекомендации |
| `app/parts.ts` | Расходники, совместимость, варианты и наборы обслуживания |
| `app/data/filament-source.json` | Нормализованные данные из таблицы филамента |
| `app/data/parts-source.json` | Нормализованные данные из таблицы расходников |
| `public/images/` | Фотографии товаров и логотипы клиентов |
| `ASSET-SOURCES.md` | Источники изображений и пояснения к данным каталога |
| `Dockerfile` | Сборка и production-запуск для Railway |

Каталог содержит 108 карточек товаров и наборов, 14 моделей принтеров. Данные из исходных таблиц включены в JSON; оригинальные Excel-файлы для запуска не требуются.

## 5. Что работает как демонстрация

Интерфейс, навигация, фильтры, переключение RU/UZ и корзина работают в браузере. Корзина сохраняется в sessionStorage в рамках сеанса браузера.

Авторизация, платежи, отправка заявок, Telegram, CRM и учёт остатков не подключены. Формы показывают демонстрационные подтверждения. Часть цен и остатков — примеры; незаполненные данные отображаются как «уточняются». Перед реальными продажами замените демонстрационные данные и подключите нужные сервисы.

## 6. Проверка экспорта

Проверки этого архива описаны в `VERIFICATION.md`. Развёртывание в вашем аккаунте Railway выполняется после загрузки на GitHub.

Официальные инструкции:

- [Railway: Dockerfiles](https://docs.railway.com/guides/dockerfiles)
- [Railway: Next.js и GitHub](https://docs.railway.com/guides/nextjs)
- [Railway: публичный адрес](https://docs.railway.com/networking/public-networking)
- [Railway: healthcheck](https://docs.railway.com/deployments/healthchecks)
- [Next.js: standalone-сборка](https://nextjs.org/docs/app/api-reference/config/next-config-js/output)

## Переменные окружения (Railway → Variables)

| Переменная | Зачем |
|---|---|
| `TELEGRAM_BOT_TOKEN` | токен бота от @BotFather — заказы и B2B-заявки уходят в Telegram |
| `TELEGRAM_CHAT_ID` | куда слать заказы; несколько id через запятую |
| `CONTACT_PHONE` | телефон на сайте, например `+998 90 123 45 67` |
| `CONTACT_TELEGRAM` | username менеджера без @, например `forma3d_uz` |
| `SITE_URL` | адрес сайта для canonical/sitemap, по умолчанию `https://forma-3d.uz` |

Для поисковиков: `/sitemap.xml`, `/robots.txt`, у каждой страницы свой title/description, каталог — `/ru/catalog`, запчасти — `/ru/catalog/parts`, товар — `/ru/product/<id>`.
